// 1. Feladat----------------
function Rng(alsoHatar, felsoHatar) {
    var generaltSzam = (Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar);
    return generaltSzam;
}
var rngEredmeny = Rng(10, 20);
console.log(rngEredmeny);
// 2. Feladat----------------
function TombGenerator(meret, alsoHatar, felsoHatar) {
    var VizsgaltTomb = [];
    for (var i = 0; i < meret; i++) {
        VizsgaltTomb.push(Rng(alsoHatar, felsoHatar));
    }
    return VizsgaltTomb;
}
var tombGeneratorEredemeny = TombGenerator(5, 10, 20);
console.log(tombGeneratorEredemeny);
// 3. Feladat
function Duplazo(VizsgaltTomb) {
    var megduplazottTomb = [];
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        megduplazottTomb.push(VizsgaltTomb[i] * 2);
    }
    return megduplazottTomb;
}
var duplaEredmeny = Duplazo(TombGenerator(5, 10, 20));
console.log(duplaEredmeny);
// 4. Feladat
function PrimekSzama(VizsgaltTomb) {
    var darab = 0;
    var oszto = 0;
    for (var i = 0; i < VizsgaltTomb.length; i++) {
        for (var j = 2; j <= Math.sqrt(VizsgaltTomb[i]); j++) {
            if (VizsgaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        if (oszto === 0 && VizsgaltTomb[i] > 1) {
            for (var i_1 = 0; i_1 < VizsgaltTomb.length; i_1++) {
                if (VizsgaltTomb[i_1] % 2 === 0) {
                    darab++;
                }
            }
        }
    }
    return darab;
}
var primVizsgalo = PrimekSzama(TombGenerator(5, 10, 20));
console.log(primVizsgalo);
