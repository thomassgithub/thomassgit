// 1. Feladat----------------
function Rng(alsoHatar:number,felsoHatar:number):number{
    let generaltSzam:number=(Math.round(Math.random()*(felsoHatar-alsoHatar))+alsoHatar);
    return generaltSzam;
}
var rngEredmeny:number=Rng(10,20);
console.log(rngEredmeny);

// 2. Feladat----------------
function TombGenerator(meret:number,alsoHatar:number,felsoHatar:number):Array<number>{
    let VizsgaltTomb:number[]=[];
    for(let i:number=0;i<meret;i++){
        VizsgaltTomb.push(Rng(alsoHatar,felsoHatar));
    }
    return VizsgaltTomb;
}
var tombGeneratorEredemeny:number[]=TombGenerator(5,10,20);
console.log(tombGeneratorEredemeny);

// 3. Feladat
function Duplazo(VizsgaltTomb:number[]):Array<number>{
    let megduplazottTomb:number[]=[];
    for(let i:number=0;i<VizsgaltTomb.length;i++){
        megduplazottTomb.push(VizsgaltTomb[i]*2)
    }
    return megduplazottTomb;
}
var duplaEredmeny:number[]=Duplazo(TombGenerator(5,10,20));
console.log(duplaEredmeny);

// 4. Feladat
function PrimekSzama(VizsgaltTomb:number[]):number{
    let darab:number=0;
    let oszto:number=0;
    for(let i:number=0;i<VizsgaltTomb.length;i++){
        for(let j:number=2;j<=Math.sqrt(VizsgaltTomb[i]);j++){
            if(VizsgaltTomb[i]%j===0){
                oszto++;
            }
        }
        if(oszto===0 && VizsgaltTomb[i]>1){
            for(let i:number=0;i<VizsgaltTomb.length;i++){
                if(VizsgaltTomb[i]%2===0){
                    darab++;
                }
            }
        }
    }
    
    return darab;
}
var primVizsgalo:number=PrimekSzama(TombGenerator(5,10,20));
console.log(primVizsgalo);