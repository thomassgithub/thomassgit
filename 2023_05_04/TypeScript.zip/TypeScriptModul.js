//1. Feladat
function PhErtek(vizsgaltErtek) {
    if (vizsgaltErtek < 7) {
        return "savas";
    }
    else if (vizsgaltErtek > 7) {
        return "lugos";
    }
    return "semleges";
}
//2. Feladat
function PrimekSzama(vizsgaltTomb) {
    let generaltTomb = [];
    let primekSzama = 0;
    let darab = 0;
    for (let i = 0; i < vizsgaltTomb.length; i++) {
        let randomTomb = Math.round(Math.random() * 100);
        generaltTomb.push(randomTomb);
    }
    for (let j = 0; j < generaltTomb.length; j++) {
        let oszto = 0;
        for (let i = 2; i <= Math.sqrt(generaltTomb[i]); j++) {
            if (generaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            darab++;
        }
    }
    return primekSzama;
}
//3. Feladat
function MaganHangzokSzama(vizsgaltSzoveg) {
    let maganHangzok = "aáeéiíöőüűóouú";
    let szamlalo = 0;
    for (let i = 0; i < vizsgaltSzoveg.length; i++) {
        if (maganHangzok.indexOf(vizsgaltSzoveg[i]) !== -1) {
            szamlalo++;
        }
    }
    return szamlalo;
}
