//1. Feladat
function PhErtek(vizsgaltErtek: number): string {
    if (vizsgaltErtek < 7) {
        return "savas"
    }
    else if (vizsgaltErtek > 7) {
        return "lugos"
    }
    return "semleges"
}
//2. Feladat
function PrimekSzama(vizsgaltTomb: number[]): number {
    let generaltTomb: number[] = [];
    let primekSzama: number = 0;
    let darab: number = 0;
    for (let i: number = 0; i < vizsgaltTomb.length; i++) {
        let randomTomb: number = Math.round(Math.random() * 100);
        generaltTomb.push(randomTomb)
    }
    for (let j: number = 0; j < generaltTomb.length; j++) {
        let oszto: number = 0;
        for (let i: number = 2; i <= Math.sqrt(generaltTomb[i]); j++) {
            if (generaltTomb[i] % j === 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            darab++;
        }
    }

        
return primekSzama;
}

//3. Feladat
function MaganHangzokSzama(vizsgaltSzoveg:string):number{
    let maganHangzok:string="aáeéiíöőüűóouú";
    let szamlalo:number=0;
    for(let i:number=0;i<vizsgaltSzoveg.length;i++){
        if(maganHangzok.indexOf(vizsgaltSzoveg[i])!==-1){
            szamlalo++;
        }
    }
    return szamlalo;

}