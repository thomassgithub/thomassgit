<script>

/*Név: Fleck Tamás
Csoport: Junior Front-end és Webfejlesztő
Team: 11*/
//1. feladat - Készítő
function keszito(){
	document.write("Név: Fleck Tamás<br>Csoport: Junior Front-end és Webfejlesztő<br>Team: 11");
}
//2. feladat - Hatványozás
function hatvanyozo(szam, hatvany){
	let eredmeny=szam**hatvany;
    return eredmeny;
}
//3. feladat - Páros számok kigenerálása
function parosLetrehoz(also,felso){
	let generaltParosSzam=Math.round(Math.random()*(felso-also))+also;
    if(generaltParosSzam%2==0){
    	return generaltParosSzam;
    }
    else if(generaltParosSzam!=felso){
    	generaltParosSzam=generaltParosSzam+1;
        return generaltParosSzam;
    }
    else{
    	generaltParosSzam=generaltParosSzam-1;
        return generaltParosSzam;
    }
}
//4. feladat Testtömeg Index
function testTomegIndex(suly,magassag){
	TTI=suly/(magassag*magassag);
    if (TTI<16){
    	let sulyosSovanysag="Súlyosan sovány vagy";
		return sulyosSovanysag;
        document.write("Sovány");
	}
	else if (TTI<17){
    	let mersekeltSovanysag="Mérsékelten sovány vagy";
        return mersekeltSovanysag;
	}
	else if (TTI<18.5){
		let enyhenSovanysag="Enyhén sovány vagy";
        return enyhenSovanysag;
	}
	else if (TTI<25){
		let normalisTestsuly="Normális a testsúlyod";
        return normalisTestsuly;
	}
	else if (TTI<30){
		let tulsulyos="Túlsúlyos vagy";
        return tulsulyos;
	}
	else if (TTI<35){
		let IfokuElhizas="I. fokú elhízásba szenvedsz";
        return IfokuElhizas;
	}
	else{
		let IIfokuElhizas="II. fokú elhízásba szenvedsz";
        return IIfokuElhizas;
	}
}
//5. feladat - Osztó-e
function egeszOsztoE(szam,oszto){
	if(szam%oszto==0){
    	return true
    }
    else{
    	return false
    }
}
//----------
document.write("1. feladat:<br>");
keszito()
document.write("<hr>");
document.write("2. feladat - A hatvány értéke: "+hatvanyozo(5,3)+"<br>");
document.write("<hr>");
document.write("3. feladat - A generált páros szám: "+parosLetrehoz(1,100)+"<br>");
document.write("<hr>");
document.write("4. feladat - Testsúly Index: "+testTomegIndex(71,1.8)+"<br>");
document.write("<hr>");
document.write("5. feladat:<br>");
document.write(egeszOsztoE(25,5)+"<br>");
document.write(egeszOsztoE(1050,7)+"<br>");
document.write(egeszOsztoE(2048,3)+"<br>");
</script>