// tsc TypeScriptModul.ts
function EkezetesBetukSzama(vizsgaltSzoveg:string):number{
    let darab:number=0;
    let ekezetesBetuk:string="öüóőúéáűíÖÜÓŐÚÉÁŰÍ";
    for(let i:number=0;i<vizsgaltSzoveg.length;i++){
        for(let j:number=0;j<ekezetesBetuk.length;j++){
            if(vizsgaltSzoveg[i]==ekezetesBetuk[j]){
                darab++;
            }
        }
    }
    return darab;
}
function ElsoNszamSzorzat(mennyiseg:number):number{
    let kapottErtek:number=1;
    for(let i:number=1;i<mennyiseg;i++){
        kapottErtek=mennyiseg*mennyiseg[i];
    }
    return kapottErtek;
}
function ParosakOsszege(vizsgaltTomb:number[]):number{
    let parosSzamOsszeg:number=0;
    for(let i:number=0;i<vizsgaltTomb.length;i++){
        if(vizsgaltTomb[i]%2==0){
            parosSzamOsszeg+=vizsgaltTomb[i];
        }
    }
    return parosSzamOsszeg;
}