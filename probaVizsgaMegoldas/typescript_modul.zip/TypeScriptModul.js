// tsc TypeScriptModul.ts
function EkezetesBetukSzama(vizsgaltSzoveg) {
    var darab = 0;
    var ekezetesBetuk = "öüóőúéáűíÖÜÓŐÚÉÁŰÍ";
    for (var i = 0; i < vizsgaltSzoveg.length; i++) {
        for (var j = 0; j < ekezetesBetuk.length; j++) {
            if (vizsgaltSzoveg[i] == ekezetesBetuk[j]) {
                darab++;
            }
        }
    }
    return darab;
}
function ElsoNszamSzorzat(mennyiseg) {
    var kapottErtek = 1;
    for (var i = 1; i < mennyiseg; i++) {
        kapottErtek = mennyiseg * mennyiseg[i];
    }
    return kapottErtek;
}
function ParosakOsszege(vizsgaltTomb) {
    var parosSzamOsszeg = 0;
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        if (vizsgaltTomb[i] % 2 == 0) {
            parosSzamOsszeg += vizsgaltTomb[i];
        }
    }
    return parosSzamOsszeg;
}
