import { Component } from '@angular/core';

@Component({
  selector: 'app-vizsgafeladat',
  templateUrl: './vizsgafeladat.component.html',
  styleUrls: ['./vizsgafeladat.component.css']
})
export class VizsgafeladatComponent {
  sulyInput:number=0;
  magassagInput:number=0;
  TTI(suly:number,magassag:number):number{
    let testTomegIndex:number=suly/(magassag*magassag);
    return testTomegIndex;
  }
  eredmeny:number=this.TTI(this.sulyInput,this.magassagInput);
  EredmenyMentes(){
    if(this.TTI(this.sulyInput,this.magassagInput)){
      this.megoldasok.push(`A(z) ${this.sulyInput}testsúlyú és ${this.magassagInput} magasságú ember testtömeg indexe ${this.TTI}`);
    }
  }
  megoldasok:any[]=[];
}

