<script>
/*Fleck Tamás
Csoportazonosító: Team 11
HTML:100%
CSS: 90%
Javascript: 70%*/
document.write("Az első 10 négyzetszám a következő: ");
for(let i=1;i<=10;i++){
	document.write(`${i**2}, `);
}
</script>