<script>
document.write("Fleck Tamás<br>");
document.write("Csoportazonosító: Team 11<br>");
document.write("HTML:100%<br>");
document.write("CSS: 90%<br>");
document.write("Javascript: 70%<br>");
</script>