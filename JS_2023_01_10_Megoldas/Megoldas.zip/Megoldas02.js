<script>
/*Fleck Tamás
Csoportazonosító: Team 11
HTML:100%
CSS: 90%
Javascript: 70%*/
let szam=prompt("Adj meg egy számot" );
let hatvany=prompt("Add meg a hatvány mértékét");
let eredmeny=szam**hatvany;
document.write(`A ${szam} <sup>${hatvany}</sup> értéke: ${eredmeny}`);
</script>
