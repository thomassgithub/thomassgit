<script>
/*Fleck Tamás
Csoportazonosító: Team 11
HTML:100%
CSS: 90%
Javascript: 70%*/
let also=prompt("Add meg az alsó határt: ");
let felso=prompt("Add meg a felső határt: ");
let parosSzam=Math.round(Math.random()*(felso-also))+also;
if(parosSzam%2==0){
	document.write(parosSzam);
}
</script>