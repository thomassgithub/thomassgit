<script>
/*Fleck Tamás
Csoportazonosító: Team 11
HTML:100%
CSS: 90%
Javascript: 70%*/
let eletKor=prompt("Add meg az életkort 1 és 120 között: ");
if(eletKor<1 || eletKor>120){
	document.write("Hibás adat. 1 és 120 közötti értéket adj meg");
}
else{
	if(eletKor<7){
    	document.write("Az illető kisgyermek");
    }
    else if(eletKor<13){
    	document.write("Az illető gyermek");
    }
    else if(eletKor<17){
        document.write("Az illető serdülő");
    }
    else if(eletKor<21){
        document.write("Az illető ifjú");
    }
    else if(eletKor<31){
        document.write("Az illető fiatal felnőtt");
    }
    else if(eletKor<61){
        document.write("Az illető felnőtt");
    }
    else{
        document.write("Az illető agg");
    }
}
</script>