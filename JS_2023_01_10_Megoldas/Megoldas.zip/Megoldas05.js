<script>
/*Fleck Tamás
Csoportazonosító: Team 11
HTML:100%
CSS: 90%
Javascript: 70%*/
let szam=prompt("Adj meg egy számot: ");
let oszto=prompt("Add meg az osztót: ");
if(szam%oszto==0){
	document.write(`A ${oszto} osztja a ${szam}-t maradék nélkül`);
}
else{
	document.write(`A ${oszto} NEM osztja a ${szam}-t maradék nélkül`);
}
</script>