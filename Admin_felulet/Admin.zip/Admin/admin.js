aktivalo.addEventListener("click",mindenCheck);
function mindenCheck(){
    let elemlista=document.querySelectorAll(".allapot");
    for(let i=0;i<elemlista.length;i++){
        elemlista[i].checked=true;
    }
}
deaktivalo.addEventListener("click",mindenUnCheck);
function mindenUnCheck(){
    let elemlista=document.querySelectorAll(".allapot");
    for(let i=0;i<elemlista.length;i++){
        elemlista[i].checked=false;
    }
}
aktivaloOnOff.addEventListener("click",AktivalOnOff);
function AktivalOnOff(){
    let elemlista=document.querySelectorAll(".allapot");
    for(let i=0;i<elemlista.length;i++){
        if(elemlista[i].checked==true){
            elemlista[i].checked=false;
        }
        else if(elemlista[i].checked==false){
            elemlista[i].checked=true;
        }
    }
}
csikozasbe.addEventListener("click",CsikozasBe);
function CsikozasBe(){
    let tableObjektum=document.querySelector("table");
    tableObjektum.classList.add("table-striped");
}
csikozaski.addEventListener("click",CsikozasKi);
function CsikozasKi(){
    let tableObjektum=document.querySelector("table");
    tableObjektum.classList.remove("table-striped");
}
csikozasOnOff.addEventListener("click",savozasOnOff);
    function savozasOnOff(){
        let tableObjektum=document.querySelector("table");
        let csikozasbe=tableObjektum.classList.add("table-striped");
        let csikozaski=tableObjektum.classList.remove("table-striped");
        if(csikozasbe==true){
            csikozasbe=csikozaski;
        }
        else if(csikozaski==true){
            csikozasbe=csikozaski;
        }
    }
darkMode.addEventListener("click",DarkMode);
function DarkMode(){
    let tableObjektum=document.querySelector("table");
    tableObjektum.classList.remove("table-light");
    tableObjektum.classList.add("table-dark");
}
lightMode.addEventListener("click",LightMode);
function LightMode(){
    let tableObjektum=document.querySelector("table");
    tableObjektum.classList.remove("table-dark");
    tableObjektum.classList.add("table-light");
}
tesztSor.addEventListener("click",TesztSorBeszuras);
function TesztSorBeszuras(){
    let tableObjektum=document.querySelector("table");
    let sor=tableObjektum.insertRow();
    let vezNevCella=sor.insertCell();
    let kerNevCella=sor.insertCell();
    let emailCella=sor.insertCell();
    let telefonCella=sor.insertCell();
    let beosztasCella=sor.insertCell();
    let aktivalCella=sor.insertCell();
    vezNevCella.innerHTML="teszt";
    kerNevCella.innerHTML="teszt";
    emailCella.innerHTML="teszt";
    telefonCella.innerHTML="teszt";
    beosztasCella.innerHTML="teszt";
    aktivalCella.innerHTML="<input type=\"checkbox\" class=\"allapot\">";
}