//1. Feladat------------------
function DiakInfo(nev:string, csoport:number, tipus:boolean){
    if(tipus==true){
        return "Junior Frontend"
    }
    else if(tipus==false){
        return "Webprogramozó"
    }
    return nev;
}
var diakInfoEredmeny:any=DiakInfo("Fleck Tamás",11,true);
console.log(diakInfoEredmeny);

//2. Feladat------------------
function SzovegesErtekeles(jegy:number):[string,string]{
    if(jegy==5){
        return ["Példás","Példás"];
    }
    if(jegy==4){
        return ["Jó","Jó"];
    }
    if(jegy==3){
        return ["Változó","Változó"];
    }
    if(jegy==2){
        return ["Hanyag","Rossz"];
    }
}
var ertekelesEredmeny:[string,string]=SzovegesErtekeles(2);
console.log(ertekelesEredmeny);

//3. Feladat------------------
function HarommalOszthatokSzama(szam:Array<number>):number{
    let harommalOszthatoSzamok:number=0;
    for(let i:number=0;i<szam.length;i++){
        if(szam[i]%3==0){
            harommalOszthatoSzamok++;
        }
    }
    return harommalOszthatoSzamok;
}
var harommalOszthatoSzamokEredmeny:number=HarommalOszthatokSzama([10, 23,12, 24, 31, 33, 42, 20]);
console.log(harommalOszthatoSzamokEredmeny);

//4. Feladat------------------
function Nyeroszamok(mennyiseg:number,alsoHatar:number,felsoHatar:number):Array<number>{
    let kigeneraltTomb:Array<number>=[];
    for(let i:number=0;i<mennyiseg;i++){
        kigeneraltTomb.push(Math.round(Math.random()*(felsoHatar-alsoHatar))+alsoHatar);
    }
    return kigeneraltTomb;
}
var nyeroSzamokEredmeny:number[]=Nyeroszamok(5,1,90);
console.log(nyeroSzamokEredmeny);