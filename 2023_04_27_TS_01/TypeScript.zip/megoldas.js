//1. Feladat------------------
function DiakInfo(nev, csoport, tipus) {
    if (tipus == true) {
        return "Junior Frontend";
    }
    else if (tipus == false) {
        return "Webprogramozó";
    }
    return nev;
}
var diakInfoEredmeny = DiakInfo("Fleck Tamás", 11, true);
console.log(diakInfoEredmeny);
//2. Feladat------------------
function SzovegesErtekeles(jegy) {
    if (jegy == 5) {
        return ["Példás", "Példás"];
    }
    if (jegy == 4) {
        return ["Jó", "Jó"];
    }
    if (jegy == 3) {
        return ["Változó", "Változó"];
    }
    if (jegy == 2) {
        return ["Hanyag", "Rossz"];
    }
}
var ertekelesEredmeny = SzovegesErtekeles(2);
console.log(ertekelesEredmeny);
//3. Feladat------------------
function HarommalOszthatokSzama(szam) {
    var harommalOszthatoSzamok = 0;
    for (var i = 0; i < szam.length; i++) {
        if (szam[i] % 3 == 0) {
            harommalOszthatoSzamok++;
        }
    }
    return harommalOszthatoSzamok;
}
var harommalOszthatoSzamokEredmeny = HarommalOszthatokSzama([10, 23, 12, 24, 31, 33, 42, 20]);
console.log(harommalOszthatoSzamokEredmeny);
//4. Feladat------------------
function Nyeroszamok(mennyiseg, alsoHatar, felsoHatar) {
    var kigeneraltTomb = [];
    for (var i = 0; i < mennyiseg; i++) {
        kigeneraltTomb.push(Math.round(Math.random() * (felsoHatar - alsoHatar)) + alsoHatar);
    }
    return kigeneraltTomb;
}
var nyeroSzamokEredmeny = Nyeroszamok(5, 1, 90);
console.log(nyeroSzamokEredmeny);
