var EuropaiUnio = [{
        orszag: "Ausztria",
        csatlakozas: "1995.01.01"
    },
    {
        orszag: "Belgium",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Bulgária",
        csatlakozas: "2007.01.01"
    },
    {
        orszag: "Ciprus",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Csehország",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Dánia",
        csatlakozas: "1973.01.01"
    },
    {
        orszag: "Egyesült Királyság",
        csatlakozas: "1973.01.01"
    },
    {
        orszag: "Észtország",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Finnország",
        csatlakozas: "1995.01.01"
    },
    {
        orszag: "Franciaország",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Görögország",
        csatlakozas: "1981.01.01"
    },
    {
        orszag: "Hollandia",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Horvátország",
        csatlakozas: "2013.07.01"
    },
    {
        orszag: "Írország",
        csatlakozas: "1973.01.01"
    },
    {
        orszag: "Lengyelország",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Lettország",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Litvánia",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Luxemburg",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Magyarország",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Málta",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Németország",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Olaszország",
        csatlakozas: "1958.01.01"
    },
    {
        orszag: "Portugália",
        csatlakozas: "1986.01.01"
    },
    {
        orszag: "Románia",
        csatlakozas: "2007.01.01"
    },
    {
        orszag: "Spanyolország",
        csatlakozas: "1986.01.01"
    },
    {
        orszag: "Svédország",
        csatlakozas: "1995.01.01"
    },
    {
        orszag: "Szlovákia",
        csatlakozas: "2004.05.01"
    },
    {
        orszag: "Szlovénia",
        csatlakozas: "2004.05.01"
    }
];
function OrszagokSzama(EuAdatok) {
    var darab = 0;
    for (var i = 0; i < EuAdatok.length; i++) {
        darab++;
    }
    console.log(darab);
}
OrszagokSzama(EuropaiUnio);
function K7(EuAdatok) {
    var darab = 0;
    var keresettEvszam = 2007;
    for (var i = 0; i < EuAdatok.length; i++) {
        var csatlakozasEv = Number(EuAdatok[i].csatlakozas.substring(0, 4));
        if (csatlakozasEv == keresettEvszam) {
            darab++;
        }
    }
    console.log(darab + " ország csatlakozott az Unióhoz ebben az évben: " + keresettEvszam);
}
K7(EuropaiUnio);
function KeresettOrszag(EuAdatok) {
    var szerepelE = false;
    var adottOrszag = "Magyarország";
    for (var i = 0; i < EuAdatok.length; i++) {
        if (EuAdatok[i].orszag == adottOrszag) {
            szerepelE = true;
        }
    }
    if (szerepelE == true) {
        console.log(adottOrszag + " szerepel a listán");
    }
    else {
        console.log(adottOrszag + " nem szerepel a listán");
    }
}
KeresettOrszag(EuropaiUnio);
function Majus(EuAdatok) {
    var majus = 5;
    var szerepelE = false;
    for (var i = 0; i < EuAdatok.length; i++) {
        var csatlakozasDatum = EuAdatok[i].csatlakozas;
        var csatlakozasHonap = Number(csatlakozasDatum.substring(6, 7));
        if (csatlakozasHonap == majus) {
            szerepelE = true;
        }
    }
    if (szerepelE == true) {
        console.log("Volt Májusban csatlakozás");
    }
    else {
        console.log("Nem volt Májusban csatlakozás");
    }
}
Majus(EuropaiUnio);
function UtolsoCsatlakozo(EuAdatok) {
    var maxIndex = 0;
    for (var i = 0; i < EuAdatok.length; i++) {
        var aktIndexEv = Number(EuAdatok[i].csatlakozas.substring(0, 4));
        var maxIndexEv = Number(EuAdatok[maxIndex].csatlakozas.substring(0, 4));
        if (aktIndexEv > maxIndexEv) {
            maxIndex = i;
        }
    }
    console.log(EuAdatok[maxIndex].orszag);
}
UtolsoCsatlakozo(EuropaiUnio);
