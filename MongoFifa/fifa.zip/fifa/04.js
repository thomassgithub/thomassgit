var MongoClient = require("mongodb").MongoClient;
var url="mongodb+srv://FT:t11project@cluster0.nsnttfr.mongodb.net/T11Project";

async function tobbAdatkiOlvasas(){
    try{
        const client=await MongoClient.connect(url);
        const db=client.db("Fifa");
        const collection=db.collection("Fifa");


        const rendezesBeallitasa={Helyezes: 1}

        const eredmeny=await collection.find({Helyezes:{$lt:4}}).sort(rendezesBeallitasa).toArray();

        console.log("A kiolvasott adat:",eredmeny)
        client.close();        
    }
    catch(err){
        console.error("Hiba történt az adat olvasása során",err);
    }
}
tobbAdatkiOlvasas();