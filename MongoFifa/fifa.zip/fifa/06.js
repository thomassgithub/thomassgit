var MongoClient = require("mongodb").MongoClient;
var url="mongodb+srv://FT:t11project@cluster0.nsnttfr.mongodb.net/T11Project";

async function tobbAdatkiOlvasas(){
    try{
        const client=await MongoClient.connect(url);
        const db=client.db("Fifa");
        const collection=db.collection("Fifa");


    

        const eredmeny=await collection.find({Pontszam:{$gt:1600}},{projection:{_id:0,Helyezes:1,Csapat:1}}).toArray();

        console.log("A kiolvasott adat:",eredmeny)
        client.close();        
    }
    catch(err){
        console.error("Hiba történt az adat olvasása során",err);
    }
}
tobbAdatkiOlvasas();