var MongoClient = require("mongodb").MongoClient;
var url="mongodb+srv://FT:t11project@cluster0.nsnttfr.mongodb.net/T11Project";

async function kollekcióKeszites(){
    try{
        const client=await MongoClient.connect(url);
        const db=client.db("Fifa");
        await db.createCollection("Fifa");
        console.log("A kollekció létrejött");
        client.close();
    }
    catch(err){
        console.error("Hiba történt a kollekció létrehozása során",err);
    }
}
kollekcióKeszites();