//Csapat
//Helyezes
//Valtozas
//Pontszam
var MongoClient = require("mongodb").MongoClient;
var url = "mongodb+srv://FT:t11project@cluster0.nsnttfr.mongodb.net/T11Project";

async function adatFeltoltes() {
    try {
        const client = await MongoClient.connect(url);
        const db = client.db("Fifa");

        var fifa = [
            {
                Csapat: "Anglia",
                Helyezes: 4,
                Valtozas: 0,
                Pontszam: 1662
            },
            {
                Csapat: "Argentína",
                Helyezes: 10,
                Valtozas: 0,
                Pontszam: 1614
            },
            {
                Csapat: "Belgium",
                Helyezes: 1,
                Valtozas: 0,
                Pontszam: 1752
            },
            {
                Csapat: "Brazília",
                Helyezes: 3,
                Valtozas: -1,
                Pontszam: 1719
            },
            {
                Csapat: "Chile",
                Helyezes: 17,
                Valtozas: -3,
                Pontszam: 1576
            },
            {
                Csapat: "Dánia",
                Helyezes: 14,
                Valtozas: -1,
                Pontszam: 1584
            },
            {
                Csapat: "Franciaország",
                Helyezes: 2,
                Valtozas: 1,
                Pontszam: 1725
            },
            {
                Csapat: "Hollandia",
                Helyezes: 13,
                Valtozas: 3,
                Pontszam: 1586
            },
            {
                Csapat: "Horvátország",
                Helyezes: 8,
                Valtozas: -1,
                Pontszam: 1625
            },
            {
                Csapat: "Kolumbia",
                Helyezes: 9,
                Valtozas: -1,
                Pontszam: 1622
            },
            {
                Csapat: "Mexikó",
                Helyezes: 12,
                Valtozas: 0,
                Pontszam: 1603
            },
            {
                Csapat: "Németország",
                Helyezes: 16,
                Valtozas: -1,
                Pontszam: 1580
            },
            {
                Csapat: "Olaszország",
                Helyezes: 15,
                Valtozas: 1,
                Pontszam: 1583
            },
            {
                Csapat: "Peru",
                Helyezes: 19,
                Valtozas: 0,
                Pontszam: 1551
            },
            {
                Csapat: "Portugália",
                Helyezes: 5,
                Valtozas: 1,
                Pontszam: 1643
            },
            {
                Csapat: "Spanyolország",
                Helyezes: 7,
                Valtozas: 2,
                Pontszam: 1631
            },
            {
                Csapat: "Svájc",
                Helyezes: 11,
                Valtozas: 0,
                Pontszam: 1604
            },
            {
                Csapat: "Svédország",
                Helyezes: 18,
                Valtozas: 0,
                Pontszam: 1560
            },
            {
                Csapat: "Szenegál",
                Helyezes: 20,
                Valtozas: 0,
                Pontszam: 1546
            },
            {
                Csapat: "Uruguay",
                Helyezes: 6,
                Valtozas: -1,
                Pontszam: 1639
            },
            
        ]


        await db.collection("Fifa").insertMany(fifa);
        console.log("Feltöltés sikeres");
        client.close();
    }
    catch (err) {
        console.error("Hiba történt a kollekció létrehozása során", err);
    }
}
adatFeltoltes();