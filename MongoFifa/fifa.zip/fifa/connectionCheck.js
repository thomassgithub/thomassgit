var MongoClient = require("mongodb").MongoClient;
var url="mongodb+srv://FT:t11project@cluster0.nsnttfr.mongodb.net/T11Project";

async function ellenorzes(){
    try{
        const client=await MongoClient.connect(url);
        console.log("Sikeres csatlakozás");
        client.close;
    }
    catch(err){
        console.error("Hiba történt a csatlakozás során",err);
    }
}
ellenorzes();