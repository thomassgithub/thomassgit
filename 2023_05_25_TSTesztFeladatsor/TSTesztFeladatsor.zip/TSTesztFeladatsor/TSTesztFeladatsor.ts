function EkezetesBetukSzama(modositandoSzoveg:string):number{
    let ekezetesBetuk:string[]=["ű", "á", "é", "ú", "ő", "ó", "ü", "ö","Ű","Á","É","Ú","Ő","Ó","Ü","Ö"];
    let darab:number=0;
    for(let i:number=0;i<modositandoSzoveg.length;i++){
        for(let j:number=0;j<ekezetesBetuk.length;j++){
            if(modositandoSzoveg[i]==ekezetesBetuk[j]){
                darab++
            }
        }
    }
    return darab;
}
function PrimLista(vizsgaltTomb:number[]):any{
    let primekSzama:number[]=[];
    for(let i=0;i<vizsgaltTomb.length;i++){
        let oszto:number=0;
        for(let j=1;j<=vizsgaltTomb[i];j++){
            if(vizsgaltTomb[i]%j==0){
                oszto++;
            }
        }
        if(oszto==2){
            primekSzama.push(vizsgaltTomb[i]);
        }
    }
    return primekSzama;
}