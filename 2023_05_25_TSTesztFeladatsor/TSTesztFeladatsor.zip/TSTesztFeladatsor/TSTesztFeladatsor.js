function EkezetesBetukSzama(modositandoSzoveg) {
    var ekezetesBetuk = ["ű", "á", "é", "ú", "ő", "ó", "ü", "ö", "Ű", "Á", "É", "Ú", "Ő", "Ó", "Ü", "Ö"];
    var darab = 0;
    for (var i = 0; i < modositandoSzoveg.length; i++) {
        for (var j = 0; j < ekezetesBetuk.length; j++) {
            if (modositandoSzoveg[i] == ekezetesBetuk[j]) {
                darab++;
            }
        }
    }
    return darab;
}
function PrimLista(vizsgaltTomb) {
    var primekSzama = [];
    for (var i = 0; i < vizsgaltTomb.length; i++) {
        var oszto = 0;
        for (var j = 1; j <= vizsgaltTomb[i]; j++) {
            if (vizsgaltTomb[i] % j == 0) {
                oszto++;
            }
        }
        if (oszto == 2) {
            primekSzama.push(vizsgaltTomb[i]);
        }
    }
    return primekSzama;
}
